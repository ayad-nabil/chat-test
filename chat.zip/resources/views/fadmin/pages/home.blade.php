@extends('fadmin.master')

@section('content')
    <div id="main-content" class="home-page">
        <h1>لوحة التحكم</h1>
    </div>
@endsection