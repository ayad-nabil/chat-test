<?php namespace App;


use Illuminate\Database\Eloquent\Model;

class PublicMsg extends Model {

    protected $table = 'publicMsg';

}