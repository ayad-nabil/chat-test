<?php namespace App;


use Illuminate\Database\Eloquent\Model;

class ExcpelReg extends Model {

    protected $table = 'excpelsReg';

}