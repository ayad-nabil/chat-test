<?php namespace App;


use Illuminate\Database\Eloquent\Model;

class NotificationReg extends Model {

    protected $table = 'notificationsReg';

}