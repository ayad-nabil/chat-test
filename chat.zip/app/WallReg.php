<?php namespace App;


use Illuminate\Database\Eloquent\Model;

class WallReg extends Model {

    protected $table = 'wallReg';

}