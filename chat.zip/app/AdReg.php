<?php namespace App;


use Illuminate\Database\Eloquent\Model;

class AdReg extends Model {

    protected $table = 'adsReg';

}