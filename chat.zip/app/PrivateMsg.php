<?php namespace App;


use Illuminate\Database\Eloquent\Model;

class PrivateMsg extends Model {

    protected $table = 'private_messages';

}