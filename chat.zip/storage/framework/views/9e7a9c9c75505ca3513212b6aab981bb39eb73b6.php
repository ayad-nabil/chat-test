<div class="sidebar">
    <ul class="nav nav-sidebar">
        <?php if(\App\Http\Controllers\FadminController::can($token, "admin")): ?>
            <li class="<?php echo e($page == "home" ? "active" : ""); ?>"><a href="<?php echo e("/fadmn/home/".$token); ?>">اللوحة</a></li>
        <?php endif; ?>
        <?php if(\App\Http\Controllers\FadminController::can($token, "admin_reg")): ?>
            <li class="<?php echo e($page == "reg" ? "active" : ""); ?>"><a href="<?php echo e("/fadmn/reg/".$token); ?>">السجل</a></li>
        <?php endif; ?>
        <?php if(\App\Http\Controllers\FadminController::can($token, "admin_events")): ?>
            <li class="<?php echo e($page == "events" ? "active" : ""); ?>"><a  href="<?php echo e("/fadmn/events/".$token); ?>">الأحداث</a></li>
        <?php endif; ?>
        <?php if(\App\Http\Controllers\FadminController::can($token, "admin_users")): ?>
            <li class="<?php echo e($page == "users" ? "active" : ""); ?>"><a  href="<?php echo e("/fadmn/users/".$token); ?>">الأعضاء</a></li>
        <?php endif; ?>
        <?php if(\App\Http\Controllers\FadminController::can($token, "admin_supers")): ?>
            <li class="<?php echo e($page == "subscriptions" ? "active" : ""); ?>"><a  href="<?php echo e("/fadmn/subscriptions/".$token); ?>">الإشتراكات</a></li>
        <?php endif; ?>
        <?php if(\App\Http\Controllers\FadminController::can($token, "admin_virtuals")): ?>
            <li class="<?php echo e($page == "virtuals" ? "active" : ""); ?>"><a  href="<?php echo e("/fadmn/virtuals/".$token); ?>">الوهميين</a></li>
        <?php endif; ?>
        <?php if(\App\Http\Controllers\FadminController::can($token, "admin_rooms")): ?>
            <li class="<?php echo e($page == "rooms" ? "active" : ""); ?>"><a  href="<?php echo e("/fadmn/rooms/".$token); ?>">الغرف</a></li>
        <?php endif; ?>
        <?php if(\App\Http\Controllers\FadminController::can($token, "admin_banneds")): ?>
            <li class="<?php echo e($page == "ban" ? "active" : ""); ?>"><a  href="<?php echo e("/fadmn/ban/".$token); ?>">الحظر</a></li>
        <?php endif; ?>
        <?php if(\App\Http\Controllers\FadminController::can($token, "edit_permissions")): ?>
            <li class="<?php echo e($page == "privileges" ? "active" : ""); ?>"><a  href="<?php echo e("/fadmn/privileges/".$token); ?>">الصلاحيات</a></li>
        <?php endif; ?>
        <?php if(\App\Http\Controllers\FadminController::can($token, "admin_settings")): ?>
            <li class="<?php echo e($page == "filter" ? "active" : ""); ?>"><a  href="<?php echo e("/fadmn/filter/".$token); ?>">فلتر</a></li>
        <?php endif; ?>
        <?php if(\App\Http\Controllers\FadminController::can($token, "admin_settings")): ?>
            <li class="<?php echo e($page == "filtered-words" ? "active" : ""); ?>"><a  href="<?php echo e("/fadmn/filtered-words/".$token); ?>">الكلمات المفلترة</a></li>
        <?php endif; ?>
        <?php if(\App\Http\Controllers\FadminController::can($token, "admin_settings")): ?>
            <li class="<?php echo e($page == "gifts-and-faces" ? "active" : ""); ?>"><a  href="<?php echo e("/fadmn/gifts-and-faces/".$token); ?>">الفيسات و الهدايا</a></li>
        <?php endif; ?>
        <?php if(\App\Http\Controllers\FadminController::can($token, "admin_settings")): ?>
            <li class="<?php echo e($page == "self-messages" ? "active" : ""); ?>"><a  href="<?php echo e("/fadmn/self-messages/".$token); ?>">الرسائل التلقائية</a></li>
        <?php endif; ?>
        <?php if(\App\Http\Controllers\FadminController::can($token, "admin_settings")): ?>
            <li class="<?php echo e($page == "shortcuts" ? "active" : ""); ?>"><a  href="<?php echo e("/fadmn/shortcuts/".$token); ?>">الإختصارات</a></li>
        <?php endif; ?>
        <?php if(\App\Http\Controllers\FadminController::can($token, "admin_settings")): ?>
            <li class="<?php echo e($page == "settings" ? "active" : ""); ?>"><a  href="<?php echo e("/fadmn/settings/".$token); ?>">الإعدادات</a></li>
        <?php endif; ?>
        <?php if(\App\Http\Controllers\FadminController::can($token, "admin_settings")): ?>
            <li class="<?php echo e($page == "developer" ? "active" : ""); ?>"><a  href="<?php echo e("/fadmn/developer/".$token); ?>">خاص بالمطورين</a></li>
        <?php endif; ?>
    </ul>
</div>