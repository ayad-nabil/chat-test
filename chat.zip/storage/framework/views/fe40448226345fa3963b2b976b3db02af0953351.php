<?php $__env->startSection('content'); ?>
    <div id="main-content" class="home-page">
        <h1>لوحة التحكم</h1>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('fadmin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>