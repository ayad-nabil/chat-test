<!doctype html>
<html lang="ar">
<head>
    <meta charset="UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge" />
    <meta property="og:title" content='<?php echo e(settings('chat_title')); ?>' />
    <meta property="og:description" content="<?php echo e(settings('chat_desc')); ?>" />
    <meta property="og:image" content="" />
    <meta name="google" content="notranslate" />
    
    <meta name="viewport" content="width=device-width, user-scalable=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="mobile-web-app-capable" content="yes" />

    <link rel="icon" type="image/x-icon" href="/favicon.png" />

    <title><?php echo e(settings("chat_title")); ?></title>
    <meta name="description" content="<?php echo e(settings('chat_desc')); ?>" />
    <meta name="keywords"    content="<?php echo e(settings('chat_keywords')); ?>" />

    
    <meta name="theme-color" content="<?php echo e(settings('window_color')); ?>" />
    
    <meta name="msapplication-navbutton-color" content="<?php echo e(settings('window_color')); ?>" />
    
    <meta name="apple-mobile-web-app-status-bar-style" content="<?php echo e(settings('window_color')); ?>" />
    <script src="<?php echo e(url('js/socket.io.js')); ?>"></script>

    <link rel="stylesheet" href="<?php echo e(asset("font-awesome-4.7.0/css/font-awesome.min.css")); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('/css/app.css?v=1')); ?>" />
    <style><?php echo e(settings("css")); ?></style>

</head>
<body>

    <div id="app"></div>
    <script >
        var socketHost = '<?php echo e(env("SOCKET_IO_HOST")); ?>';
        var settings = <?php echo json_encode(\App\Settings::parse()); ?>;
    </script>
<script>
    // var socket = io('http://localhost:8000');
    // socket.on('connect', function(){alert("asddsa")});
    // socket.on('event', function(data){});
    // socket.on('disconnect', function(){});
  </script> 
    <script src="<?php echo e(asset("/js/simplewebrtc.js")); ?>"></script>
    <script src="<?php echo e(asset("/js/clientjs.js")); ?>"></script>
    <script src="<?php echo e(asset("/js/app.js?v=1")); ?>"></script>

</body>
</html>