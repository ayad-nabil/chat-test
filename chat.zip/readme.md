## Begiin Mic

	new file:   node/event-handlers/RadioHandler.js
	new file:   node/models/Radio.js
	new file:   public/images/mic.png
	new file:   public/images/sound-off.png
	new file:   public/images/sound-on.png
	new file:   public/images/stop-mic.png
	new file:   public/js/simplewebrtc.js
	new file:   resources/assets/event-handlers/RadioHandler.js
	new file:   resources/assets/react/components/chat/profile-actions/CancelRadio.js
	new file:   resources/assets/redux/actions/radioConnectionReadyAction.js
	new file:   resources/assets/redux/actions/webrtc.js
	new file:   resources/assets/redux/reducers/setRadioConnectionReadyReducer.js
	new file:   resources/assets/redux/reducers/setWebrtcReducer.js
	
    modified:   app/Http/Controllers/FadminController.php
    modified:   node/api/Connection.js
    modified:   node/event-handlers/AuthHandler.js
    modified:   node/event-handlers/RoomsHandler.js
    modified:   node/models/Permissions.js
    modified:   node/models/User.js
    modified:   node/server.js
    modified:   resources/assets/js/helpers.js
    modified:   resources/assets/react/components/chat/Chat.js
    modified:   resources/assets/react/components/chat/body/MessageInput.js
    modified:   resources/assets/react/components/chat/body/UserItem.js
    modified:   resources/assets/react/components/chat/body/UsersPane.js
    modified:   resources/assets/react/components/chat/modals/UserProfile.js
    modified:   resources/assets/redux/init-store.js
    modified:   resources/assets/sass/chat/_message-input.scss
    modified:   resources/assets/sass/chat/_user-item.scss
    modified:   resources/views/fadmin/pages/privileges.blade.php
    modified:   resources/views/master.blade.php

## End Mic